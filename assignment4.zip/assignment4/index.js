//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//MONGO SETUP
//0. import mongoose library
const mongoose = require("mongoose")
const Schema = mongoose.Schema;

//1. connect to mongo db
//confirm connectection successful
// url of your database
const mongoURL = "mongodb+srv://dbUser:0000@cluster0.szjjn.mongodb.net/assignment4?retryWrites=true&w=majority"

// configuration options to use when connecting to the database
const connectionOptions = {useNewUrlParser: true, useUnifiedTopology: true}

//2. define table
const ItemSchema = new Schema({
    name:String,
    rarity:String,
    description:String,
    goldPerTurn:Number
})
const Item = mongoose.model("items_table", ItemSchema)

//3. insert data into table
// const item1 = new Item({name: "Magpie", rarity:"common", description: "Gives 9 gold every 4 spins", goldPerTurn:-1})
// const item2 = new Item({name: "King Midas", rarity:"rare", description: "Adds 1 Gold each turn. Adjacent Gold gives 3x more gold.", goldPerTurn:2})
// const item3 = new Item({name: "Goose", rarity:"common", description: "Has a 1% chance of adding a Golden Egg", goldPerTurn:1})
// const item4 = new Item({name: "Bee", rarity:"uncommon", description: "Adjacent Flowers give 2x more Gold", goldPerTurn:1})
// const item5 = new Item({name: "Golden Egg", rarity:"rare", description: "", goldPerTurn:3})
// const item6 = new Item({name: "Cat", rarity:"common", description: "", goldPerTurn:1})
// const item7 = new Item({name: "Void Stone", rarity:"uncommon", description: "Adjacent empty squares give 1 coin more. Destroys itself if adjacent to 0 empty squares. Gives 8 coins when destroyed", goldPerTurn:0})

// Item.create([item1, item2, item3, item4, item5, item6, item7]).then(
//     () => {
//         console.log("Bulk insert with create was successful")
//     }
// ).catch(
//     (err) => {
//         console.log("Error bulk inserting with create into the table")
//         console.log(err)
//     }
// )

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//EXPRESS SETUP
const express = require("express");
const app = express();
app.use(express.json())
const HTTP_PORT = process.env.PORT || 8080;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ENDPOINTS
// GET ALL
app.get("/api/items", (req, res) => {
    //1. search the database for items and return them
    Item.find().exec().then(
        (results) => {
            console.log(results)
            res.send(results)
        }
    ).catch(
        (err) => {
            console.log(err)
            res.status(500).send("Error when getting items from database")
        }
    )
})

// DELETE BY ID
app.delete("/api/items/:item_name", (req,res) => {
    console.log(`Searching for: ${req.params.item_name}`)
    Item.findOneAndDelete({name: req.params.item_name}).exec().then(
        (deletedItem) => {
            console.log(`Result from database:`)
            console.log(deletedItem)
            if (deletedItem === null){
                console.log("Record not found")
                const msg = {
                    statusCode:404,
                    msg: "Record not found"
                }
                res.status(404).send(msg)
            } else {
                console.log(`${req.params.item_name} found and deleted!`)
                const msg = {
                    statusCode: 200, 
                    msg: "Item found and deleted!"
                }
                res.status(200).send(msg)
            }
        }
    ).catch(
        (err) => {
            console.log(`Error`)
            console.log(err)
            const msg = {
                statusCode:500,
                msg: "Error when getting items from database."
            }
            res.status(500).send(msg)
        }
    )
})


// GET ONE BY NAME
app.get("/api/items/:item_name", (req,res) => {
    console.log(`Searching for: ${req.params.item_name}`)
    Item.findOne({name: req.params.item_name}).exec().then(
        (foundItem) => {
            console.log(`Result from database:`)
            console.log(foundItem)
            if (foundItem === null){            
                console.log("Record not found")
                const msg = {
                    statusCode:404,
                    msg: "Record not found"
                }
                res.status(404).send(msg)
            } else {
                res.send(foundItem)
            }
        }
    ).catch(
        (err) => {
            console.log(`Error`)
            console.log(err)
            const msg = {
                statusCode:500,
                msg: "Error when getting items from database."
            }
            res.status(500).send(msg)
        }
    )
    
})

// INSERT 
app.post("/api/items", (req, res) => {
    console.log("Received this from client:")
    console.log(req.body)

    if ("name" in req.body && "rarity" in req.body){
    Item.create(req.body).then(
        (result) => {
            //JS
            console.log("Create success!")
            console.log(result)
            //EXPRESS
            const msg = {
                statusCode:201, 
                msg: "Insert item successful!"
            }
            res.status(201).send(msg)
        }).catch(
        (err) => {
            console.log(`Error`)
            console.log(err)
            const msg = {
                statusCode:500,
                msg: "Error when getting items from database"
            }
            res.status(500).send(msg)
        }
    )
}
else{
    res.status(401).send({"msg":"Sorry, you are missing a name or a rarity in your JSON payload"})
}})


// UPDATE BY ID
app.put("/api/items/:id", (req,res) => {
    const msg = {
        statusCode:501,
        msg: "Not implemented, stay tuned for future updates"
    }
    res.status(501).send(msg)
})
//OTHER ENDPOINTS
app.get("/:other", (req, res) => {
    const msg = {
        statusCode:404,
        msg: "Not found"
    }
    res.status(404).send(msg)
})
app.get("/", (req, res) => {
    const msg = {
        statusCode:404,
        msg: "Assignment 4"
    }
    res.status(404).send(msg)
})
app.get("/api/:other", (req, res) => {
    const msg = {
        statusCode:404,
        msg: "Not found"
    }
    res.status(404).send(msg)
})

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// connect to the database and check that it worked
// and start server
const onHttpStart = () => {
    console.log(`Server has started and is listening on port ${HTTP_PORT}`)
}

mongoose.connect(mongoURL, connectionOptions).then(
    () => {
        console.log("Connected successfully")
        app.listen(HTTP_PORT, onHttpStart);
    }
).catch(
    (err) => {
        console.log("Error connecting to database")
        console.log(err)
    }
)